# Payment Gateway Integration #

* Simple donation website using Instamojo as a payment gateway.

https://abhishek-bodapati.github.io/Payment_Integration_Gateway/

### Card credentials for testing: ###
* #### Debit Card number: #### 
   4242 4242 4242 4242
* #### Expiry: ####
   Any valid future date
* #### CVV: #### 
   Any 3 digit number
* #### 3D-Secure Password: ####
   1221

### Youtube Link: ###
https://youtu.be/Z6AHq_E7HhQ

### API Link: ###
https://test.instamojo.com/developers/
